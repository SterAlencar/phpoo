<!DOCTYPE html>
<html lang="pt-br">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Fotografias IFSP - Login</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,600;1,700&family=Inter:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&family=Cardo:ital,wght@0,400;0,700;1,400&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/main.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: PhotoFolio
  * Updated: Jul 27 2023 with Bootstrap v5.3.1
  * Template URL: https://bootstrapmade.com/photofolio-bootstrap-photography-website-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>
  <header id="header" class="header d-flex align-items-center fixed-top">
    <div class="container-fluid d-flex align-items-center justify-content-between">
      <a href="index.html" class="logo d-flex align-items-center me-auto me-lg-0">
        <img src="assets/img/logo-if.png" alt="" class="logo-img">
        <h1 class="logo-text">IF Fotografias</h1>
      </a>
    </div>
    <nav id="navbar" class="navbar text-center">
      <ul class="justify-content-center">
        
        <?php 
        if (isset($_SESSION["nomeusuario"])) {
          echo "<li><a href='cadastro.php' class='btn-get-started'>".$_SESSION['nomeusuario']."</a></li>";
        } else {
          echo "<li><a href='cadastro.php'>Cadastro</a></li>";
        }
        ?>

        <li><a href="services.php">Serviços</a></li>
      </ul>
    </nav><!-- .navbar -->
  </header>

  <main>
    <section class="container-admin-banner">
      <img src="../img/logo-if.png" class="logo-admin" alt="logo-serenatto">
      <h1>Login IFSP Fotografias</h1>
      <img class="ornaments" src="../img/logo-if.png" alt="ornaments">
    </section>

    <div class="container">
      <div class="row justify-content-center">
        <div class="col-md-6">
          <div class="form-container">
            <form method="post" action="processar-login.php">
              <div class="mb-3">
                <label for="email" class="form-label">E-mail</label>
                <input type="email" id="email" name="email" class="form-control" placeholder="Digite o seu e-mail" required>
              </div>

              <div class="mb-3">
                <label for="senha" class="form-label">Senha</label>
                <input type="password" id="senha" name="senha" class="form-control" placeholder="Digite a sua senha" required>
              </div>

              <button type="submit" class="btn btn-primary">Entrar</button>

              <?php if (isset($_GET["erro"])){ ?>
                <div class="text-danger">Usuário ou senha inválidos</div>
              <?php }?>
            </form>
          </div>

          <div class="form-container">
            <form action="cadastro.php" method="post">
              <button type="submit" name="cadastro" class="btn btn-primary">Usuário novo</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </main>

  <!-- Bootstrap JS, Popper.js, and jQuery -->
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>

</html>
