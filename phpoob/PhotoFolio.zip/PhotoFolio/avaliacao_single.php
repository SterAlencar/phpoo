<!DOCTYPE html>
<html lang="pt-br">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Fotografias IFSP - Avaliação Individual</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Adicione os mesmos Favicons, Google Fonts, Vendor CSS, e o Main CSS File da sua página principal -->

  <!-- =======================================================
  * Template Name: PhotoFolio
  * Updated: Jul 27 2023 with Bootstrap v5.3.1
  * Template URL: https://bootstrapmade.com/photofolio-bootstrap-photography-website-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- Adicione o mesmo Header da sua página principal -->

  <main id="main" data-aos="fade" data-aos-delay="1500">

    <section id="avaliacao-single" class="avaliacao-single">
      <div class="container">

        <!-- Adicione o conteúdo para exibir a avaliação individual -->
        <!-- Você pode incluir um formulário de envio de avaliação aqui -->

      </div>
    </section><!-- End Avaliacao Single Section -->

  </main><!-- End #main -->

  <!-- Adicione o mesmo Footer da sua página principal -->

</body>

</html>
