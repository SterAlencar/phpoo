<?php
include 'conexao.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Recupere os dados do formulário
    $nome = mysqli_real_escape_string($conexao, $_POST["nome"]);
    $comentario = mysqli_real_escape_string($conexao, $_POST["comentario"]);

    // Verifique se os dados são válidos antes de prosseguir

    // Prepare e execute a consulta SQL para inserir o comentário
    $query = "INSERT INTO comentarios (nome, comentario, data_envio) VALUES ('$nome', '$comentario', NOW())";

    if ($conexao->query($query) === TRUE) {
        // Redirecione de volta para a página de avaliações após o processamento
        header("Location: avaliacoes.php");
        exit();
    } else {
        echo "Erro ao inserir o comentário: " . $conexao->error;
    }

    // Feche a conexão com o banco de dados
    $conexao->close();
} else {
    // Se alguém tentar acessar este script diretamente sem enviar dados do formulário, redirecione
    header("Location: avaliacoes.php");
    exit();
}
?>