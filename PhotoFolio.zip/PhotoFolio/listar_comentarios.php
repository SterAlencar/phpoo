<?php
$conexao = new mysqli("localhost", "root", "", "site_fotos_db");

// Verificar conexão
if ($conexao->connect_error) {
    die("Falha na conexão com o banco de dados: " . $conexao->connect_error);
}

// Consulta SQL para obter todos os comentários
$sql = "SELECT * FROM comentarios";
$resultado = $conexao->query($sql);

// Exibe os comentários
while ($comentario = $resultado->fetch_assoc()) {
    echo '<div>';
    echo '<strong>' . $comentario["nome"] . ':</strong> ' . $comentario["comentario"];
    echo ' <a href="editar_comentario.php?id=' . $comentario["id"] . '">Editar</a>';
    echo ' <a href="apagar_comentario.php?id=' . $comentario["id"] . '">Apagar</a>';
    echo '</div>';
}

// Fechar a conexão
$conexao->close();
?>