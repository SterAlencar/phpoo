<!DOCTYPE html>
<html lang="pt-br">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Fotografias IFSP - Avaliações</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,600;1,700&family=Inter:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&family=Cardo:ital,wght@0,400;0,700;1,400&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/main.css" rel="stylesheet">

  <!-- Include raty.js library -->
  <script src="caminho/para/jquery.min.js"></script>
  <script src="caminho/para/jquery.raty.js"></script>

  <script>
    $(document).ready(function () {
      $('.avaliacao-link').raty({
        score: function () {
          return $(this).attr('data-score');
        },
        readOnly: false,
        click: function (score, evt) {
          var imageId = $(this).closest('.gallery-item').index() + 1;
          alert('Imagem ' + imageId + ' avaliada com ' + score + ' estrelas');
          $.post('enviar_avaliacao.php', { imageId: imageId, score: score });
        }
      });
    });
  </script>
</head>

<body>
  <header id="header" class="header d-flex align-items-center fixed-top">
    <div class="container-fluid d-flex align-items-center justify-content-between">
      <a href="index.html" class="logo d-flex align-items-center me-auto me-lg-0">
        <img src="assets/img/logo-if.png" alt="" class="logo-img">
        <h1 class="logo-text">IF Fotografias</h1>
      </a>
      <nav id="navbar" class="navbar text-center">
        <ul class="justify-content-center">
          <li><a href="index.php">Home</a></li>
          <?php
          if (isset($_SESSION["nomeusuario"])) {
            echo "<li><a href='cadastro.php' class='btn-get-started'>" . $_SESSION['nomeusuario'] . "</a></li>";
          } else {
            echo "<li><a href='cadastro.php'>Cadastro</a></li>";
          }
          ?>
          <li><a href="about.php">Sobre Nós</a></li>
          <li class="dropdown"><a href="#" class="active"><span>Galeria</span> <i class="bi bi-chevron-down dropdown-indicator"></i></a>
          </li>
          <li><a href="services.php">Serviços</a></li>
          <li><a href="login.php">Login</a></li>
        </ul>
      </nav><!-- .navbar -->
    </div>
  </header>

  <main>
    <section class="container-admin-banner">
      <img src="../img/logo-if.png" class="logo-admin" alt="logo-if">
      <h1>Avaliações</h1>

    </section>

    <!-- ... Seu código HTML existente ... -->

    <!-- ... Seções anteriores ... -->

    <div class="container">
      <!-- Seção de Avaliações -->
      <section id="avaliacoes" class="avaliacoes">
        <div class="container-fluid">
          <!-- Seu código de avaliações existente ... -->
        </div>
      </section>

      <!-- Seção de Comentários -->
      <section id="comentarios" class="comentarios">
        <div class="container">
          <h2>Comentários</h2>
          <form method="post" action="processar_comentario.php">
            <div class="mb-3">
              <label for="nome" class="form-label">Nome:</label>
              <input type="text" class="form-control" id="nome" name="nome" required>
            </div>
            <div class="mb-3">
              <label for="comentario" class="form-label">Comentário:</label>
              <textarea class="form-control" id="comentario" name="comentario" rows="4" required></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Enviar Comentário</button>
          </form>

          <!-- Exibir Comentários -->
          <?php
// Incluir arquivo de conexão com o banco de dados
include 'conexao.php';

// Verificar se o formulário de edição foi enviado
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["edit_comment"])) {
    // Recuperar os dados do formulário de edição
    $comment_id = mysqli_real_escape_string($conexao, $_POST["comment_id"]);
    $edited_comment = mysqli_real_escape_string($conexao, $_POST["edited_comment"]);

    // Atualizar o comentário no banco de dados
    $update_query = "UPDATE comentarios SET comentario = '$edited_comment' WHERE id = $comment_id";
    $conexao->query($update_query);
}

// Verificar se o formulário de exclusão foi enviado
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["delete_comment"])) {
    // Recuperar o ID do comentário a ser excluído
    $comment_id = mysqli_real_escape_string($conexao, $_POST["comment_id"]);

    // Excluir o comentário do banco de dados
    $delete_query = "DELETE FROM comentarios WHERE id = $comment_id";
    $conexao->query($delete_query);
}

// Consulta SQL para recuperar os comentários
$query_comentarios = "SELECT id, nome, comentario FROM comentarios ORDER BY data_envio DESC LIMIT 3";
$result_comentarios = $conexao->query($query_comentarios);

// Verificar se a consulta foi bem-sucedida
if ($result_comentarios !== FALSE) {
    ?>
    <div class="mt-4">
        <h3>Comentários Recentes:</h3>
        <?php
        // Loop para exibir os comentários do banco de dados
        while ($row = $result_comentarios->fetch_assoc()) {
            ?>
            <div class="card mt-3">
                <div class="card-body">
                    <h5 class="card-title"><?php echo htmlspecialchars($row['nome']); ?></h5>
                    <p class="card-text"><?php echo htmlspecialchars($row['comentario']); ?></p>

                    <!-- Adicionar botões de editar e apagar -->
                    <form method="post" action="">
                        <input type="hidden" name="comment_id" value="<?php echo $row['id']; ?>">
                        <textarea name="edited_comment" class="form-control" rows="2" style="margin-bottom: 5px;"><?php echo htmlspecialchars($row['comentario']); ?></textarea>
                        <button type="submit" name="edit_comment" class="btn btn-primary btn-sm">Reenviar</button>
                    </form>
                    
                    <form method="post" action="" onsubmit="return confirm('Tem certeza que deseja apagar este comentário?');">
                        <input type="hidden" name="comment_id" value="<?php echo $row['id']; ?>">
                        <button type="submit" name="delete_comment" class="btn btn-danger btn-sm">Apagar</button>
                    </form>
                </div>
            </div>
            <?php
        }
        ?>
    </div>
    <?php
} else {
    echo "Erro ao recuperar comentários: " . $conexao->error;
}

// Fechar a conexão com o banco de dados
$conexao->close();
?>


        </div>
      </section>
    </div>
  </main>

<!-- ... Seu código HTML existente ... -->
<footer id="footer" class="footer">
    <div class="container">
      <div class="copyright">
        &copy; <strong><span>Fotografia IFSP</span></strong>. Todos os direitos reservados.
      </div>
      <div class="credits">
        <!-- All the links in the footer should remain intact. -->
        <!-- You can delete the links only if you purchased the pro version. -->
        <!-- Licensing information: https://bootstrapmade.com/license/ -->
        <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/photofolio-bootstrap-photography-website-template/ -->
        Designed by <a href="https://instagram.com/ifspgru?igshid=MzRlODBiNWFlZA==">Noemi, Stefany e Neemias</a>
      </div>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <div id="preloader">
    <div class="line"></div>
  </div>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>