create database photofolio;
use photofolio;
create table usuario (
nome varchar(255),
email varchar(255) primary key,
senha varchar(255));
select * from usuario;

drop database photofolio;

CREATE DATABASE site_fotos_db;
USE site_fotos_db;
CREATE TABLE comentarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    comentario TEXT NOT NULL,
    data_envio TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
select * from comentarios;

drop database site_fotos_db;