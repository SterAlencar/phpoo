<?php
$servername = "localhost";
$username = "root";
$password = "";
$databasename = "photofolio";
$databasename = "site_fotos_db";

// Criação da conexão
$conn = new mysqli($servername, $username, $password, $databasename);
$conexao = new mysqli($servername, $username, $password, $databasename);

// Verificando a conexão
if ($conexao->connect_error) {
    die("Conexão falhou: " . $conexao->connect_error);
}

// Verificando a conexão
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
} else {
    echo "Conexão bem-sucedida ao banco de dados";
}
?>