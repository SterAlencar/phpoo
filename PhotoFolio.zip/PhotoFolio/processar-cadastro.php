<?php
include 'conexao.php';
include 'Usuario.php';

if (($_SERVER["REQUEST_METHOD"]=="POST")){
$nome = $_POST["nome"];
$email = $_POST["email"];
$senha = $_POST["senha"];
$confirmarsenha = $_POST["confirmarsenha"];

if ($senha === $confirmarsenha){
//conexão com o banco de dados;
$usuario = new Usuario($conn);
//cadastrar o usuário
if ($usuario->cadastrar($nome,$email,$senha,$confirmarsenha)){
// Redirecionar para a página de sucesso após o cadastro
header("Location: cadastro-sucesso.php");
exit();
}else{
echo "erro! tente novamente!";
}
} else {
header("Location: cadastro.php?erro=1");
}

}

session_start();

// Lógica de cadastro...

// Após o cadastro bem-sucedido, defina a variável de sessão
$_SESSION['nomeusuario'] = $_POST['nome']; // Substitua 'nome' pelo campo correto do seu formulário

// Redirecione para a página principal ou outra página desejada
header("Location: index.php");
exit();

?>
